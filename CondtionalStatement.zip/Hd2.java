//Write a program to check if a given integer number is odd or even.
import java.util.Scanner;

public class Hd2 {

	public static void main(String[] args) {

		        Scanner sc=new Scanner(System.in);
		        System.out.println("enter the integer");
		        int i=sc.nextInt();
		        if(i%2==0)
		        {
		        	System.out.println("even");
		        }
		        else
		        {
		        	System.out.println("odd");
		        }
		        
			}



	}


